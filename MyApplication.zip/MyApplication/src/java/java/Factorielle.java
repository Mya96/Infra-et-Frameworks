/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java;

/**
 *
 * @author NDEYE AMY DIOP
 */
public class Factorielle {
    

    private static int f = 1;
    private static String myString;

    public static String calculFactorielle(int valeur) {

        if (valeur <= 0) {
            throw new IllegalArgumentException("Positive number only");
        }

        for (int i = 1; i <= valeur; i++) {
            int a = f;
            f=a*i;
            myString += (a+ "*" +i+ "=" +f+ "\n");
        }
        return myString;

    }
}
